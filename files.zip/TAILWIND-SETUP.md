# Tailwind CSS Setup (If Needed)

The Fantasy IPL app uses Tailwind CSS for styling. **Most likely it's already working**, but if you see unstyled buttons/forms, follow these steps:

## Quick Install (1 minute)

In your `fantasy-ipl` folder, run:

```bash
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p
```

This creates:
- `tailwind.config.js`
- `postcss.config.js`

## Configure (30 seconds)

Open `tailwind.config.js` and replace the `content` section:

```javascript
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
```

## Done!

Now run:
```bash
npm start
```

All styling should work! If not, make sure `index.css` has:

```css
@tailwind base;
@tailwind components;
@tailwind utilities;
```

---

## Alternative: Skip Tailwind

If Tailwind doesn't work and you just want the app to function (without fancy styling):

1. In `src/App.jsx`, find all `className=` attributes
2. You can comment them out or remove them
3. The app will work with basic browser styling

---

**The app works with or without Tailwind - styling is optional!**