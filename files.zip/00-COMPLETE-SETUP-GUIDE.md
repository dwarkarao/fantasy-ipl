# Fantasy IPL App - Complete Setup Guide (From Scratch)

**Total Time: 30 minutes**

---

## 📋 SECTION 1: PREREQUISITES (5 mins)

### What You Need:
1. ✅ A computer (Windows, Mac, or Linux)
2. ✅ Node.js installed (https://nodejs.org/) - Download LTS version
3. ✅ Git installed (https://git-scm.com/)
4. ✅ A GitHub account (https://github.com) - Free
5. ✅ A Firebase account (https://firebase.google.com) - Free

### Verify Installation:
```bash
# Open Terminal/Command Prompt and run:
node --version
npm --version
git --version
```

All should show version numbers. If any fail, install that tool first.

---

## 🔥 SECTION 2: SET UP FIREBASE (10 mins)

### Step 2.1: Create Firebase Project
1. Go to: https://console.firebase.google.com/
2. Click **"Create a project"**
3. **Project name:** `fantasy-ipl`
4. Accept terms → **Continue**
5. Disable Google Analytics (optional) → **Create project**
6. Wait for project creation (2-3 minutes)

### Step 2.2: Enable Authentication
1. Left menu → **Authentication**
2. Click **"Get started"**
3. Click **Email/Password** option
4. Toggle **Enable** → Click **Save**

### Step 2.3: Create Test Users
1. Still in **Authentication** tab → Click **Users** tab
2. Click **"Add user"** button
3. Create 5 test users:
   ```
   Email: user1@fantasyipl.com | Password: demo123
   Email: user2@fantasyipl.com | Password: demo123
   Email: user3@fantasyipl.com | Password: demo123
   Email: user4@fantasyipl.com | Password: demo123
   Email: user5@fantasyipl.com | Password: demo123
   ```
4. Each time, click **"Add user"** → enter email → enter password → click **"Create user"**

### Step 2.4: Get Firebase Config
1. Left menu → **Project Settings** (⚙️ gear icon)
2. Scroll down to **"Your apps"** section
3. Click **Web icon** (`</>`)</strong>
4. Copy the entire config object that looks like:
```javascript
{
  apiKey: "AIzaSyD_xxxxx",
  authDomain: "fantasy-ipl-xxxxx.firebaseapp.com",
  projectId: "fantasy-ipl-xxxxx",
  storageBucket: "fantasy-ipl-xxxxx.appspot.com",
  messagingSenderId: "123456789",
  appId: "1:123456789:web:abcdef"
}
```
5. **Save this in a text file** - you'll need it later

---

## 💻 SECTION 3: SET UP REACT APP (5 mins)

### Step 3.1: Create React Project
Open Terminal/Command Prompt and run:

```bash
npx create-react-app fantasy-ipl
cd fantasy-ipl
```

Wait for installation to complete (5 minutes). You'll see:
```
We suggest that you begin by typing:
  cd fantasy-ipl
  npm start
```

### Step 3.2: Install Firebase
```bash
npm install firebase lucide-react
```

Wait for installation to complete.

### Step 3.3: Verify It Works
```bash
npm start
```

You should see:
- A browser opens at `http://localhost:3000`
- Shows a React logo and "Edit src/App.js and save to reload"
- Press `Ctrl+C` to stop

✅ **React is working!**

---

## 📝 SECTION 4: ADD APP CODE (3 mins)

### Step 4.1: Replace App.jsx
1. In your project folder, open: `src/App.jsx`
2. Delete ALL the code
3. Paste code from: **fantasy-ipl-complete-scoring.jsx** (file provided)
4. **Save the file** (Ctrl+S)

### Step 4.2: Update Firebase Config
1. In `src/App.jsx`, find this section (around line 60):
```javascript
const FIREBASE_CONFIG = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};
```

2. Replace it with your actual Firebase config from Section 2.4
3. Example after replacement:
```javascript
const FIREBASE_CONFIG = {
  apiKey: "AIzaSyD_v_xxxxx",
  authDomain: "fantasy-ipl-xyz.firebaseapp.com",
  projectId: "fantasy-ipl-xyz",
  storageBucket: "fantasy-ipl-xyz.appspot.com",
  messagingSenderId: "123456789012",
  appId: "1:123456789012:web:abcdef123456"
};
```

4. **Save the file**

---

## 🧪 SECTION 5: TEST LOCALLY (5 mins)

### Step 5.1: Run App
```bash
npm start
```

You should see:
- Browser opens at `http://localhost:3000`
- Fantasy IPL login screen appears

### Step 5.2: Test Login
1. **Select Name:** Choose any name from dropdown
2. Click **Login**
3. You should see the **Matches** page ✅

### Step 5.3: Test Features
1. Click on a match → **Pick Players**
2. Select 1 Batsman + 1 Bowler + 1 All-rounder from each team
3. Select a **Captain**
4. Click **Save Picks** → Should show "Picks saved!"
5. Click **Teams** tab → See your team
6. Click **Leaderboard** → See rankings
7. Click **Settings** ⚙️ → See admin panel

**If all works → ✅ You're ready to deploy!**

If something breaks:
- Check browser console (F12)
- Make sure Firebase config is correct
- Make sure you're still in `fantasy-ipl` folder

---

## 🌐 SECTION 6: DEPLOY TO VERCEL (5 mins)

### Step 6.1: Create GitHub Repository

1. Go to: https://github.com/new
2. **Repository name:** `fantasy-ipl`
3. **Description:** Fantasy IPL Cricket League
4. **Public** or **Private** (your choice)
5. Click **Create repository**

### Step 6.2: Push Code to GitHub

In your Terminal (in `fantasy-ipl` folder), run:

```bash
git init
git add .
git commit -m "Initial Fantasy IPL app"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/fantasy-ipl.git
git push -u origin main
```

Replace `YOUR_USERNAME` with your actual GitHub username (e.g., `dwarkarao`)

When asked for password:
- **Username:** Your GitHub username
- **Password:** Go to https://github.com/settings/tokens
  - Click **"Generate new token"** → **"Generate new token (classic)"**
  - Token name: `fantasy-ipl`
  - Expiration: 90 days
  - Scopes: Check **`repo`**
  - Click **"Generate token"**
  - **Copy the token** (looks like `ghp_xxxxx`)
  - **Paste it as password** (don't use your GitHub password)

Success message:
```
Branch 'main' set up to track remote branch 'main' from 'origin'
```

### Step 6.3: Deploy to Vercel

1. Go to: https://vercel.com
2. Sign in/up with **GitHub**
3. Click **"New Project"**
4. Find `fantasy-ipl` repository → Click it
5. Click **"Deploy"**
6. Wait 2-3 minutes
7. You'll get a **Live URL** like: `https://fantasy-ipl-xxxxx.vercel.app`

**✅ Your app is now LIVE!**

---

## 👥 SECTION 7: CREATE ALL 20 PARTICIPANT ACCOUNTS (10 mins)

Go back to Firebase Console → **Authentication** → **Users**

Create 20 accounts:
```
user1@fantasyipl.com → demo123
user2@fantasyipl.com → demo123
user3@fantasyipl.com → demo123
user4@fantasyipl.com → demo123
user5@fantasyipl.com → demo123
user6@fantasyipl.com → demo123
user7@fantasyipl.com → demo123
user8@fantasyipl.com → demo123
user9@fantasyipl.com → demo123
user10@fantasyipl.com → demo123
user11@fantasyipl.com → demo123
user12@fantasyipl.com → demo123
user13@fantasyipl.com → demo123
user14@fantasyipl.com → demo123
user15@fantasyipl.com → demo123
user16@fantasyipl.com → demo123
user17@fantasyipl.com → demo123
user18@fantasyipl.com → demo123
user19@fantasyipl.com → demo123
user20@fantasyipl.com → demo123
```

For each:
1. Click **"Add user"**
2. Enter email
3. Enter password `demo123`
4. Click **"Create user"**

---

## 🎯 SECTION 8: SHARE WITH PARTICIPANTS (2 mins)

Send your 20 participants this:

```
🏏 Fantasy IPL 2026 League

Your login link: https://fantasy-ipl-xxxxx.vercel.app

Your login credentials:
Email: user1@fantasyipl.com (or user2, user3... user20)
Password: demo123

Steps:
1. Open the link
2. Select your name from dropdown
3. Click Login
4. Pick your players for each match
5. See everyone's teams in the "Teams" tab
6. Check leaderboard in "Leaderboard" tab
```

---

## 📊 SECTION 9: AFTER EACH MATCH - ENTER STATS (Admin)

### Step 9.1: Login as Admin
1. Login with any account
2. Click **Settings** ⚙️ icon

### Step 9.2: Enter Player Performance
1. Select the **Match**
2. Select a **Player**
3. Enter their stats:
   - **Runs:** How many runs they scored
   - **Wickets:** How many wickets they took
   - **Catches:** How many catches
   - **Stumpings:** How many stumpings
   - **Run Outs:** How many run outs
   - **Runs Conceded:** How many runs they conceded (bowlers)
   - **Sixes:** How many sixes they hit
   - Check **"Man of Match"** if applicable
   - Check **"Hat-trick"** if applicable
4. Click **"Add Stats"**
5. Repeat for all players who played

### Step 9.3: Leaderboard Updates Automatically! 🎉
- Points calculate instantly
- Your custom scoring rules apply
- Special bonuses apply automatically
- Captain points double

---

## 🔧 TROUBLESHOOTING

### "npm command not found"
- Node.js not installed
- Download from https://nodejs.org/
- Restart Terminal after installing

### "Firebase config error"
- Check config in `src/App.jsx`
- Copy exact config from Firebase console
- Make sure all quotes are correct

### "Can't login to app"
- User accounts created in Firebase?
- Check email addresses exactly match
- Password must be `demo123`

### "GitHub push fails"
- Using Personal Access Token, not password?
- Token has `repo` scope checked?
- Token not expired?

### "Live app shows blank page"
- Check browser console (F12)
- Check Firebase config is correct
- Try incognito mode

---

## 📁 FILE STRUCTURE

After everything, your `fantasy-ipl` folder should have:

```
fantasy-ipl/
  ├── node_modules/          (auto-created by npm)
  ├── public/
  ├── src/
  │   ├── App.jsx            (YOUR APP CODE - replace this!)
  │   ├── App.css
  │   ├── index.js
  │   └── index.css
  ├── package.json
  ├── package-lock.json
  ├── .git/                  (auto-created by git)
  └── .gitignore
```

---

## ✅ CHECKLIST

After following all steps:

- [ ] Node.js installed
- [ ] Firebase project created
- [ ] 5 test users created in Firebase
- [ ] Firebase config copied
- [ ] React app created
- [ ] App code added to `src/App.jsx`
- [ ] Firebase config updated in code
- [ ] App tested locally (`npm start` works)
- [ ] GitHub account created
- [ ] Repository created
- [ ] Code pushed to GitHub
- [ ] App deployed to Vercel
- [ ] Live URL works
- [ ] 20 participant accounts created in Firebase
- [ ] Participants can login with test URL

---

## 🚀 YOU'RE DONE!

Your Fantasy IPL app is now:
✅ Live on the internet
✅ Accessible to all 20 participants
✅ Ready for your tournament
✅ Free forever

**Share your live URL with participants and start the league!** 🏏🎉

---

## 📞 QUICK REFERENCE

| Task | Time | Command/Link |
|------|------|------------|
| Install Node | 5 min | https://nodejs.org/ |
| Create Firebase | 5 min | https://console.firebase.google.com/ |
| Create React App | 5 min | `npx create-react-app fantasy-ipl` |
| Test Local | 5 min | `npm start` |
| Push to GitHub | 3 min | `git push -u origin main` |
| Deploy to Vercel | 3 min | https://vercel.com |
| **TOTAL** | **30 min** | ✅ LIVE APP |

---

**Questions? Check Section 9: TROUBLESHOOTING**

Good luck! 🏏✨