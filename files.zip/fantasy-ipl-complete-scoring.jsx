import React, { useState, useEffect } from 'react';
import { Trophy, Settings, LogOut, Grid3x3, Medal, Zap, Lock, ChevronDown, Plus, Edit2, Save } from 'lucide-react';

// ============ CUSTOM SCORING RULES ============
const SCORING_RULES = {
  groupMatches: {
    tripleStar: {
      runsPerRun: 6,
      pointsPerWicket: 150,
      pointsPerCatch: 20,
      runsConceededPenalty: -2,
    },
    normal: {
      runsPerRun: 1,
      pointsPerWicket: 75,
      pointsPerCatch: 10,
      runsConceededPenalty: -1,
    },
  },
  playoffs: {
    tripleStar: {
      runsPerRun: 8,
      pointsPerWicket: 250,
      pointsPerCatch: 30,
      runsConceededPenalty: -3,
    },
    singleStar: {
      runsPerRun: 6,
      pointsPerWicket: 150,
      pointsPerCatch: 20,
      runsConceededPenalty: -2,
    },
    normal: {
      runsPerRun: 1,
      pointsPerWicket: 75,
      pointsPerCatch: 20,
      runsConceededPenalty: -1,
    },
  },
  specialBonuses: {
    manOfMatch: 50,
    manOfMatchStar: 100,
    halfCentury: 25,
    century: 100,
    wicketHatrick: 100,
    threeWickets: 50,
    fiveWickets: 100,
    threeCatches: 50,
    maximumSixes: 50,
  },
};

const IPL_TEAMS = ['CSK', 'MI', 'KKR', 'RCB', 'DC', 'RR', 'PBKS', 'GT', 'LSG', 'SRH'];

const PLAYER_DATABASE = {
  CSK: {
    Batsmen: ['Ruturaj Gaikwad', 'Ajinkya Rahane', 'Shivam Dube'],
    Bowlers: ['Deepak Chahar', 'Simarjeet Singh', 'Maheesh Theekshana'],
    'All-rounders': ['Ravindra Jadeja', 'Mitchell Marsh', 'Dwayne Bravo'],
  },
  MI: {
    Batsmen: ['Rohit Sharma', 'Suryakumar Yadav', 'Dewald Brevis'],
    Bowlers: ['Jasprit Bumrah', 'Riley Meredith', 'Mahesh Pathak'],
    'All-rounders': ['Hardik Pandya', 'Tim David', 'Axar Patel'],
  },
  KKR: {
    Batsmen: ['Shreyas Iyer', 'Phil Salt', 'Rinku Singh'],
    Bowlers: ['Varun Chakravarthy', 'Mitchell Starc', 'Harshit Rana'],
    'All-rounders': ['Andre Russell', 'Nitish Rana', 'Rasikh Dar'],
  },
  RCB: {
    Batsmen: ['Virat Kohli', 'Rajat Patidar', 'Faf du Plessis'],
    Bowlers: ['Mohammed Siraj', 'Josh Hazlewood', 'Reece Topley'],
    'All-rounders': ['Glenn Maxwell', 'Anuj Rawat', 'Akshdeep Nath'],
  },
  DC: {
    Batsmen: ['David Warner', 'Prithvi Shaw', 'Rishabh Pant'],
    Bowlers: ['Kuldeep Yadav', 'Mustafizur Rahman', 'Anrich Nortje'],
    'All-rounders': ['Axar Patel', 'Mitchell Marsh', 'Lalit Yadav'],
  },
  RR: {
    Batsmen: ['Sanju Samson', 'Jos Buttler', 'Yashasvi Jaiswal'],
    Bowlers: ['Yuzvendra Chahal', 'Trent Boult', 'Sandeep Sharma'],
    'All-rounders': ['Shimron Hetmyer', 'Riyan Parag', 'James Neesham'],
  },
  PBKS: {
    Batsmen: ['Shikhar Dhawan', 'Jonny Bairstow', 'Atishi Reddy'],
    Bowlers: ['Arshdeep Singh', 'Harpreet Brar', 'Nathan Ellis'],
    'All-rounders': ['Sam Curran', 'Liam Livingstone', 'Shahrukh Khan'],
  },
  GT: {
    Batsmen: ['Shubman Gill', 'Matthew Wade', 'Sai Sudharsan'],
    Bowlers: ['Rashid Khan', 'Mohit Sharma', 'Noor Ahmad'],
    'All-rounders': ['Hardik Pandya', 'Dasun Shanaka', 'Abhinav Manohar'],
  },
  LSG: {
    Batsmen: ['KL Rahul', 'Quinton de Kock', 'Ayush Badoni'],
    Bowlers: ['Yash Thakur', 'Ravi Bishnoi', 'Mohsin Khan'],
    'All-rounders': ['Marcus Stoinis', 'Krunal Pandya', 'Naveen ul Haq'],
  },
  SRH: {
    Batsmen: ['Aiden Markram', 'Harry Brook', 'Abhishek Sharma'],
    Bowlers: ['Bhuvneshwar Kumar', 'T Natarajan', 'Marco Jansen'],
    'All-rounders': ['Marco Jansen', 'Nitish Reddy', 'Abhishek Sharma'],
  },
};

const DEMO_PARTICIPANTS = [
  { id: 'user1', name: 'Priya', color: '#FF6B6B' },
  { id: 'user2', name: 'Amit', color: '#4ECDC4' },
  { id: 'user3', name: 'Neha', color: '#45B7D1' },
  { id: 'user4', name: 'Rahul', color: '#FFA07A' },
  { id: 'user5', name: 'Pooja', color: '#98D8C8' },
];

// ============ POINT CALCULATION ============
function calculatePoints(playerStats, playerLevel, phase) {
  const rules = phase === 'playoffs' ? SCORING_RULES.playoffs : SCORING_RULES.groupMatches;
  const levelRule = rules[playerLevel] || rules.normal;

  let points = 0;
  let breakdown = {};

  // Base scoring
  const runPoints = (playerStats.runs || 0) * levelRule.runsPerRun;
  const wicketPoints = (playerStats.wickets || 0) * levelRule.pointsPerWicket;
  const catchPoints = (playerStats.catches + playerStats.stumpings + playerStats.runOuts || 0) * levelRule.pointsPerCatch;
  const concedePenalty = (playerStats.runsConceded || 0) * levelRule.runsConceededPenalty;

  points = runPoints + wicketPoints + catchPoints + concedePenalty;
  breakdown.base = { runPoints, wicketPoints, catchPoints, concedePenalty };

  // Special bonuses (non-overlapping - highest only)
  let highestBonus = 0;
  let bonusName = '';

  if (playerStats.runs >= 100) {
    highestBonus = SCORING_RULES.specialBonuses.century;
    bonusName = 'Century';
  } else if (playerStats.runs >= 50) {
    highestBonus = SCORING_RULES.specialBonuses.halfCentury;
    bonusName = 'Half-Century';
  }

  if (playerStats.wickets >= 5) {
    if (SCORING_RULES.specialBonuses.fiveWickets > highestBonus) {
      highestBonus = SCORING_RULES.specialBonuses.fiveWickets;
      bonusName = '5-Wicket Haul';
    }
  } else if (playerStats.wickets === 3 && playerStats.runs < 50) {
    if (SCORING_RULES.specialBonuses.threeWickets > highestBonus) {
      highestBonus = SCORING_RULES.specialBonuses.threeWickets;
      bonusName = '3-Wicket Haul';
    }
  }

  if (playerStats.isHattrick) {
    if (SCORING_RULES.specialBonuses.wicketHatrick > highestBonus) {
      highestBonus = SCORING_RULES.specialBonuses.wicketHatrick;
      bonusName = 'Wicket Hat-trick';
    }
  }

  if (playerStats.catches + playerStats.stumpings + playerStats.runOuts >= 3) {
    if (SCORING_RULES.specialBonuses.threeCatches > highestBonus) {
      highestBonus = SCORING_RULES.specialBonuses.threeCatches;
      bonusName = '3 Catches/Run Outs/Stumpings';
    }
  }

  if (playerStats.sixes >= 6) {
    if (SCORING_RULES.specialBonuses.maximumSixes > highestBonus) {
      highestBonus = SCORING_RULES.specialBonuses.maximumSixes;
      bonusName = 'Maximum Sixes';
    }
  }

  if (playerStats.isManOfMatch) {
    const momBonus = playerLevel === 'tripleStar' ? SCORING_RULES.specialBonuses.manOfMatchStar : SCORING_RULES.specialBonuses.manOfMatch;
    highestBonus = Math.max(highestBonus, momBonus);
    bonusName = playerLevel === 'tripleStar' ? 'MoM (Star)' : 'MoM';
  }

  points += highestBonus;
  breakdown.bonusName = bonusName;
  breakdown.bonusPoints = highestBonus;

  return { points, breakdown };
}

// ============ MAIN APP ============
export default function FantasyIPL() {
  const [currentUser, setCurrentUser] = useState(null);
  const [currentView, setCurrentView] = useState('login');
  const [phase, setPhase] = useState('groupMatches');
  const [matches, setMatches] = useState([
    { id: 1, team1: 'CSK', team2: 'MI', date: '2026-03-28', status: 'upcoming', locked: false },
    { id: 2, team1: 'KKR', team2: 'RCB', date: '2026-03-29', status: 'upcoming', locked: false },
  ]);
  const [userPicks, setUserPicks] = useState({});
  const [matchStats, setMatchStats] = useState({});
  const [playerLevels, setPlayerLevels] = useState({});
  const [selectedMatch, setSelectedMatch] = useState(null);
  const [showAdminPanel, setShowAdminPanel] = useState(false);

  const handleLogin = (userId, name) => {
    setCurrentUser({ id: userId, name });
    setCurrentView('matches');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setCurrentView('login');
  };

  const savePicks = (matchId, picks, captain) => {
    setUserPicks((prev) => ({
      ...prev,
      [matchId]: { ...prev[matchId], [currentUser.id]: { picks, captain } },
    }));
  };

  const calculateLeaderboard = () => {
    const leaderboard = DEMO_PARTICIPANTS.map((participant) => {
      let totalPoints = 0;

      Object.entries(matches).forEach(([_, match]) => {
        const picks = userPicks[match.id]?.[participant.id]?.picks;
        if (picks) {
          Object.values(picks).forEach((teamPicks) => {
            Object.values(teamPicks || {}).forEach((playerName) => {
              const stats = matchStats[`${match.id}_${playerName}`];
              const level = playerLevels[playerName] || 'normal';
              if (stats) {
                const { points } = calculatePoints(stats, level, phase);
                const isCaptain = userPicks[match.id]?.[participant.id]?.captain === playerName;
                totalPoints += isCaptain ? points * 2 : points;
              }
            });
          });
        }
      });

      return { ...participant, totalPoints };
    });

    return leaderboard.sort((a, b) => b.totalPoints - a.totalPoints);
  };

  if (currentView === 'login') {
    return <LoginScreen onLogin={handleLogin} participants={DEMO_PARTICIPANTS} />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-950">
      {/* Header */}
      <header className="bg-black/50 backdrop-blur-md border-b border-indigo-500/20 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-6 py-4 flex justify-between items-center">
          <div className="flex items-center gap-3">
            <Trophy className="w-8 h-8 text-amber-400" />
            <h1 className="text-2xl font-bold text-white">Fantasy IPL 2026</h1>
            <span className="text-xs px-3 py-1 bg-indigo-600 rounded-full text-indigo-100 font-semibold">
              {phase === 'playoffs' ? 'PLAYOFFS' : 'GROUP MATCHES'}
            </span>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex gap-2 border-r border-indigo-500/20 pr-4">
              <NavButton
                label="Picks"
                active={currentView === 'matches'}
                onClick={() => { setCurrentView('matches'); setSelectedMatch(null); }}
              />
              <NavButton
                label="Teams"
                active={currentView === 'gallery'}
                onClick={() => setCurrentView('gallery')}
              />
              <NavButton
                label="Leaderboard"
                active={currentView === 'leaderboard'}
                onClick={() => setCurrentView('leaderboard')}
              />
            </div>

            <span className="text-indigo-300 font-medium">{currentUser.name}</span>
            <button
              onClick={() => setShowAdminPanel(true)}
              className="p-2 hover:bg-indigo-500/20 rounded transition"
            >
              <Settings className="w-5 h-5 text-indigo-300" />
            </button>
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 px-4 py-2 bg-red-500/20 hover:bg-red-500/30 text-red-400 rounded transition text-sm"
            >
              <LogOut className="w-4 h-4" />
              Logout
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-6 py-8">
        {currentView === 'matches' && !selectedMatch && (
          <MatchesView
            matches={matches}
            onSelectMatch={(match) => {
              setSelectedMatch(match);
              setCurrentView('picking');
            }}
          />
        )}

        {currentView === 'picking' && selectedMatch && (
          <PlayerPickingView
            match={selectedMatch}
            onBack={() => {
              setSelectedMatch(null);
              setCurrentView('matches');
            }}
            currentUser={currentUser}
            savePicks={savePicks}
            userPicks={userPicks}
          />
        )}

        {currentView === 'gallery' && (
          <TeamGalleryView
            participants={DEMO_PARTICIPANTS}
            userPicks={userPicks}
            matches={matches}
          />
        )}

        {currentView === 'leaderboard' && (
          <LeaderboardView leaderboard={calculateLeaderboard()} />
        )}
      </main>

      {/* Admin Panel */}
      {showAdminPanel && (
        <AdminPanel
          matches={matches}
          matchStats={matchStats}
          setMatchStats={setMatchStats}
          playerLevels={playerLevels}
          setPlayerLevels={setPlayerLevels}
          phase={phase}
          setPhase={setPhase}
          onClose={() => setShowAdminPanel(false)}
          allPlayers={Object.values(PLAYER_DATABASE).flatMap((team) =>
            Object.values(team).flat()
          )}
        />
      )}
    </div>
  );
}

// ============ LOGIN SCREEN ============
function LoginScreen({ onLogin, participants }) {
  const [selectedUser, setSelectedUser] = useState(participants[0]?.id);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-indigo-950 to-slate-950 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="bg-slate-900/50 backdrop-blur-md border border-indigo-500/30 rounded-2xl p-8 shadow-2xl">
          <div className="flex justify-center mb-8">
            <Trophy className="w-16 h-16 text-amber-400 animate-bounce" />
          </div>
          <h1 className="text-4xl font-bold text-center text-white mb-2">Fantasy IPL</h1>
          <p className="text-center text-indigo-300 mb-8">2026 League</p>

          <div className="mb-6">
            <label className="block text-indigo-300 font-semibold mb-3">Select Your Name</label>
            <select
              value={selectedUser}
              onChange={(e) => setSelectedUser(e.target.value)}
              className="w-full px-4 py-3 bg-slate-800/50 border border-indigo-500/30 rounded-lg text-white focus:outline-none focus:border-indigo-500"
            >
              {participants.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </div>

          <button
            onClick={() => {
              const participant = participants.find((p) => p.id === selectedUser);
              onLogin(selectedUser, participant.name);
            }}
            className="w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-bold rounded-lg transition"
          >
            Login
          </button>

          <div className="mt-6 bg-indigo-500/10 border border-indigo-500/30 rounded-lg p-4">
            <p className="text-indigo-300 font-semibold text-sm mb-2">Available Players:</p>
            <div className="space-y-1">
              {participants.map((p) => (
                <p key={p.id} className="text-gray-400 text-xs flex items-center gap-2">
                  <span
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: p.color }}
                  />
                  {p.name}
                </p>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ============ NAV BUTTON ============
function NavButton({ label, active, onClick }) {
  return (
    <button
      onClick={onClick}
      className={`px-3 py-2 rounded-lg transition text-sm font-medium ${
        active
          ? 'bg-indigo-600 text-white'
          : 'text-indigo-300 hover:bg-indigo-500/20'
      }`}
    >
      {label}
    </button>
  );
}

// ============ MATCHES VIEW ============
function MatchesView({ matches, onSelectMatch }) {
  return (
    <div>
      <h2 className="text-3xl font-bold text-white mb-8">Upcoming Matches</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {matches.map((match) => (
          <div
            key={match.id}
            className="bg-slate-900/30 backdrop-blur border border-indigo-500/20 rounded-xl p-6 hover:border-indigo-500/50 transition cursor-pointer group"
            onClick={() => onSelectMatch(match)}
          >
            <div className="flex justify-between items-start mb-4">
              <span className="text-sm text-indigo-300 font-mono">Match {match.id}</span>
              <span className="text-xs px-2 py-1 bg-amber-500/20 text-amber-400 rounded">
                {match.status.toUpperCase()}
              </span>
            </div>

            <div className="flex items-center justify-between mb-6">
              <div className="text-center flex-1">
                <p className="text-2xl font-bold text-white">{match.team1}</p>
              </div>
              <div className="text-gray-500 font-bold mx-4">vs</div>
              <div className="text-center flex-1">
                <p className="text-2xl font-bold text-white">{match.team2}</p>
              </div>
            </div>

            <p className="text-gray-400 text-sm text-center mb-4">{match.date}</p>

            <button className="w-full py-2 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-bold rounded-lg transition">
              Pick Players
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

// ============ PLAYER PICKING VIEW ============
function PlayerPickingView({ match, onBack, currentUser, savePicks, userPicks }) {
  const existingPicks = userPicks[match.id]?.[currentUser.id];
  const [picks, setPicks] = useState(existingPicks?.picks || {});
  const [captain, setCaptain] = useState(existingPicks?.captain || null);

  const handlePlayerSelect = (team, role, player) => {
    setPicks((prev) => ({
      ...prev,
      [team]: { ...prev[team], [role]: player },
    }));
  };

  const handleSave = () => {
    if (validatePicks()) {
      savePicks(match.id, picks, captain);
      alert('Picks saved!');
      onBack();
    }
  };

  const validatePicks = () => {
    if (
      !picks[match.team1]?.Batsmen ||
      !picks[match.team1]?.Bowlers ||
      !picks[match.team1]?.['All-rounders']
    ) {
      alert(`Select all player types from ${match.team1}`);
      return false;
    }
    if (
      !picks[match.team2]?.Batsmen ||
      !picks[match.team2]?.Bowlers ||
      !picks[match.team2]?.['All-rounders']
    ) {
      alert(`Select all player types from ${match.team2}`);
      return false;
    }
    if (!captain) {
      alert('Select a captain');
      return false;
    }
    return true;
  };

  const allPicked = [
    picks[match.team1]?.Batsmen,
    picks[match.team1]?.Bowlers,
    picks[match.team1]?.['All-rounders'],
    picks[match.team2]?.Batsmen,
    picks[match.team2]?.Bowlers,
    picks[match.team2]?.['All-rounders'],
  ].filter(Boolean);

  return (
    <div>
      <button onClick={onBack} className="mb-6 px-4 py-2 bg-slate-700/50 hover:bg-slate-700 text-gray-300 rounded-lg transition">
        ← Back
      </button>

      <h2 className="text-3xl font-bold text-white mb-2">{match.team1} vs {match.team2}</h2>
      <p className="text-gray-400 mb-8">{match.date}</p>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
        {[match.team1, match.team2].map((team) => (
          <TeamPicker
            key={team}
            team={team}
            picks={picks[team] || {}}
            onSelect={(role, player) => handlePlayerSelect(team, role, player)}
          />
        ))}
      </div>

      <div className="bg-slate-900/30 backdrop-blur border border-indigo-500/20 rounded-xl p-6 mb-8">
        <h3 className="text-xl font-bold text-white mb-4">Select Captain (2x Points)</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {allPicked.map((player) => (
            <button
              key={player}
              onClick={() => setCaptain(captain === player ? null : player)}
              className={`p-3 rounded-lg border transition ${
                captain === player
                  ? 'bg-amber-500/30 border-amber-500 text-amber-200 font-bold'
                  : 'bg-slate-700/30 border-slate-600 text-gray-300 hover:border-indigo-500'
              }`}
            >
              {player}
            </button>
          ))}
        </div>
      </div>

      <button
        onClick={handleSave}
        className="w-full py-3 bg-gradient-to-r from-green-600 to-emerald-600 hover:from-green-700 hover:to-emerald-700 text-white font-bold rounded-lg transition"
      >
        Save Picks
      </button>
    </div>
  );
}

// ============ TEAM PICKER ============
function TeamPicker({ team, picks, onSelect }) {
  const roles = ['Batsmen', 'Bowlers', 'All-rounders'];

  return (
    <div className="bg-slate-900/30 backdrop-blur border border-indigo-500/20 rounded-xl p-6">
      <h3 className="text-2xl font-bold text-white mb-6">{team}</h3>

      {roles.map((role) => (
        <div key={role} className="mb-6">
          <label className="block text-sm font-semibold text-indigo-300 mb-3">
            {role} <span className="text-red-400">*</span>
          </label>
          <select
            value={picks[role] || ''}
            onChange={(e) => onSelect(role, e.target.value)}
            className="w-full px-4 py-2 bg-slate-800/50 border border-indigo-500/30 rounded-lg text-white focus:outline-none focus:border-indigo-500"
          >
            <option value="">Select {role}...</option>
            {PLAYER_DATABASE[team]?.[role]?.map((player) => (
              <option key={player} value={player}>
                {player}
              </option>
            ))}
          </select>
        </div>
      ))}
    </div>
  );
}

// ============ TEAM GALLERY VIEW ============
function TeamGalleryView({ participants, userPicks, matches }) {
  return (
    <div>
      <h2 className="text-3xl font-bold text-white mb-8">All Teams</h2>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {participants.map((participant) => (
          <TeamCard key={participant.id} participant={participant} userPicks={userPicks} matches={matches} />
        ))}
      </div>
    </div>
  );
}

function TeamCard({ participant, userPicks, matches }) {
  const [expandedMatch, setExpandedMatch] = useState(null);

  return (
    <div className="bg-slate-900/30 backdrop-blur border border-indigo-500/20 rounded-xl p-6">
      <div className="flex items-center gap-3 mb-4">
        <div className="w-10 h-10 rounded-full" style={{ backgroundColor: participant.color }} />
        <h3 className="text-lg font-bold text-white">{participant.name}</h3>
      </div>

      <div className="space-y-2">
        {matches.map((match) => {
          const picks = userPicks[match.id]?.[participant.id]?.picks;
          const hasPicks = picks && Object.keys(picks).length > 0;

          return (
            <div key={match.id}>
              <button
                onClick={() => setExpandedMatch(expandedMatch === match.id ? null : match.id)}
                className="w-full p-3 bg-slate-800/50 hover:bg-slate-800 rounded-lg text-left transition flex justify-between items-center"
              >
                <span className="text-sm text-indigo-300">
                  {match.team1} vs {match.team2}
                </span>
                {hasPicks ? <Zap className="w-4 h-4 text-amber-400" /> : <Lock className="w-4 h-4 text-gray-500" />}
              </button>

              {expandedMatch === match.id && hasPicks && (
                <div className="mt-2 p-3 bg-slate-800/30 rounded-lg text-sm space-y-2">
                  {[match.team1, match.team2].map((team) => (
                    <div key={team}>
                      <div className="text-indigo-300 font-bold">{team}</div>
                      {picks[team] && (
                        <div className="text-gray-300 text-xs ml-2 space-y-1">
                          <p>🏏 {picks[team].Batsmen}</p>
                          <p>🎯 {picks[team].Bowlers}</p>
                          <p>⭐ {picks[team]['All-rounders']}</p>
                        </div>
                      )}
                    </div>
                  ))}
                  {userPicks[match.id]?.[participant.id]?.captain && (
                    <div className="pt-2 border-t border-slate-700 text-amber-400 font-bold">
                      👑 {userPicks[match.id][participant.id].captain}
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

// ============ LEADERBOARD VIEW ============
function LeaderboardView({ leaderboard }) {
  return (
    <div>
      <h2 className="text-3xl font-bold text-white mb-8">Leaderboard</h2>

      <div className="bg-slate-900/30 backdrop-blur border border-indigo-500/20 rounded-xl overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-indigo-500/20">
              <th className="px-6 py-4 text-left text-indigo-300 font-semibold">Rank</th>
              <th className="px-6 py-4 text-left text-indigo-300 font-semibold">Player</th>
              <th className="px-6 py-4 text-right text-indigo-300 font-semibold">Points</th>
            </tr>
          </thead>
          <tbody>
            {leaderboard.map((player, idx) => (
              <tr key={player.id} className="border-b border-indigo-500/10 hover:bg-indigo-500/5">
                <td className="px-6 py-4 text-white font-bold">
                  {idx === 0 ? '🥇' : idx === 1 ? '🥈' : idx === 2 ? '🥉' : idx + 1}
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full" style={{ backgroundColor: player.color }} />
                    <span className="text-white font-medium">{player.name}</span>
                  </div>
                </td>
                <td className="px-6 py-4 text-right text-amber-400 font-bold text-lg">
                  {player.totalPoints}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ============ ADMIN PANEL ============
function AdminPanel({
  matches,
  matchStats,
  setMatchStats,
  playerLevels,
  setPlayerLevels,
  phase,
  setPhase,
  onClose,
  allPlayers,
}) {
  const [selectedMatch, setSelectedMatch] = useState(matches[0]?.id);
  const [selectedPlayer, setSelectedPlayer] = useState(allPlayers[0]);
  const [stats, setStats] = useState({
    runs: 0,
    wickets: 0,
    catches: 0,
    stumpings: 0,
    runOuts: 0,
    runsConceded: 0,
    sixes: 0,
    isManOfMatch: false,
    isHattrick: false,
  });

  const handleAddStats = () => {
    const key = `${selectedMatch}_${selectedPlayer}`;
    setMatchStats((prev) => ({
      ...prev,
      [key]: { ...stats },
    }));
    alert(`Stats added for ${selectedPlayer}`);
  };

  const handleSetLevel = (player, level) => {
    setPlayerLevels((prev) => ({
      ...prev,
      [player]: level,
    }));
  };

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-slate-900 border border-indigo-500/30 rounded-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-slate-950 border-b border-indigo-500/30 px-6 py-4 flex justify-between items-center">
          <h2 className="text-2xl font-bold text-white">Admin Panel</h2>
          <button onClick={onClose} className="text-gray-400 hover:text-white">✕</button>
        </div>

        <div className="p-6 space-y-6">
          {/* Phase Selector */}
          <div>
            <h3 className="text-lg font-bold text-indigo-300 mb-4">Tournament Phase</h3>
            <div className="flex gap-4">
              {['groupMatches', 'playoffs'].map((p) => (
                <button
                  key={p}
                  onClick={() => setPhase(p)}
                  className={`px-4 py-2 rounded-lg font-semibold transition ${
                    phase === p
                      ? 'bg-indigo-600 text-white'
                      : 'bg-slate-800 text-gray-300 hover:bg-slate-700'
                  }`}
                >
                  {p === 'groupMatches' ? 'Group Matches' : 'Playoffs'}
                </button>
              ))}
            </div>
          </div>

          {/* Player Stats Entry */}
          <div className="border-t border-indigo-500/20 pt-6">
            <h3 className="text-lg font-bold text-indigo-300 mb-4">Add Player Stats</h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm text-indigo-300 mb-2">Match</label>
                <select
                  value={selectedMatch}
                  onChange={(e) => setSelectedMatch(e.target.value)}
                  className="w-full px-4 py-2 bg-slate-800/50 border border-indigo-500/30 rounded-lg text-white"
                >
                  {matches.map((m) => (
                    <option key={m.id} value={m.id}>
                      Match {m.id}: {m.team1} vs {m.team2}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm text-indigo-300 mb-2">Player</label>
                <select
                  value={selectedPlayer}
                  onChange={(e) => setSelectedPlayer(e.target.value)}
                  className="w-full px-4 py-2 bg-slate-800/50 border border-indigo-500/30 rounded-lg text-white"
                >
                  {allPlayers.map((p) => (
                    <option key={p} value={p}>
                      {p}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mb-4">
              {['runs', 'wickets', 'catches', 'stumpings', 'runOuts', 'runsConceded', 'sixes'].map((stat) => (
                <div key={stat}>
                  <label className="block text-xs text-indigo-300 mb-1 capitalize">{stat}</label>
                  <input
                    type="number"
                    value={stats[stat]}
                    onChange={(e) => setStats((prev) => ({ ...prev, [stat]: parseInt(e.target.value) || 0 }))}
                    className="w-full px-3 py-1 bg-slate-800/50 border border-indigo-500/30 rounded text-white text-sm"
                  />
                </div>
              ))}
            </div>

            <div className="flex gap-4 mb-4">
              <label className="flex items-center gap-2 text-white cursor-pointer">
                <input
                  type="checkbox"
                  checked={stats.isManOfMatch}
                  onChange={(e) => setStats((prev) => ({ ...prev, isManOfMatch: e.target.checked }))}
                  className="w-4 h-4"
                />
                Man of Match
              </label>
              <label className="flex items-center gap-2 text-white cursor-pointer">
                <input
                  type="checkbox"
                  checked={stats.isHattrick}
                  onChange={(e) => setStats((prev) => ({ ...prev, isHattrick: e.target.checked }))}
                  className="w-4 h-4"
                />
                Wicket Hat-trick
              </label>
            </div>

            <button
              onClick={handleAddStats}
              className="w-full py-2 bg-green-600 hover:bg-green-700 text-white font-bold rounded-lg transition"
            >
              Add Stats
            </button>
          </div>

          {/* Player Levels */}
          <div className="border-t border-indigo-500/20 pt-6">
            <h3 className="text-lg font-bold text-indigo-300 mb-4">Set Player Levels</h3>
            <div className="space-y-2 max-h-48 overflow-y-auto">
              {allPlayers.map((player) => (
                <div key={player} className="flex items-center justify-between bg-slate-800/50 p-2 rounded">
                  <span className="text-sm text-gray-300">{player}</span>
                  <select
                    value={playerLevels[player] || 'normal'}
                    onChange={(e) => handleSetLevel(player, e.target.value)}
                    className="px-2 py-1 bg-slate-700 border border-indigo-500/30 rounded text-white text-xs"
                  >
                    <option value="normal">Normal</option>
                    <option value="singleStar">★ Single Star</option>
                    <option value="tripleStar">★★★ Triple Star</option>
                  </select>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-slate-950 border-t border-indigo-500/30 px-6 py-4">
          <button
            onClick={onClose}
            className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg transition"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
}