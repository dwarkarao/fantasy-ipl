# GitHub Personal Access Token - Complete Guide

**Problem:** Git push fails with "Password authentication is not supported"

**Solution:** Use Personal Access Token instead of password

---

## 🔑 CREATE GITHUB TOKEN (One-time, 3 minutes)

### Step 1: Go to Token Settings
1. Open: https://github.com/settings/tokens
2. Click **"Generate new token"** dropdown
3. Select **"Generate new token (classic)"**

### Step 2: Configure Token

Fill in these fields:

| Field | Value |
|-------|-------|
| **Note** | `fantasy-ipl` |
| **Expiration** | `90 days` (or Longer) |
| **Select scopes** | Check **`repo`** only |

### Step 3: Generate & Copy Token

1. Scroll down
2. Click **"Generate token"**
3. **IMPORTANT:** Copy the token immediately
   - It looks like: `ghp_xxxxxxxxxxxxxxxxxxxxxxxxxxxxx`
   - You WON'T see it again!
4. **Save it in a safe place** (notepad, password manager, etc.)

---

## 💾 USE TOKEN FOR GIT PUSH

### When Git Asks for Password:

```bash
git push -u origin main
```

You'll see:
```
Username for 'https://github.com': [TYPE YOUR USERNAME]
Password for 'https://dwarkarao@github.com': [PASTE TOKEN HERE]
```

**Do NOT enter your GitHub password**

### Instructions:
1. **Username:** Type your GitHub username (e.g., `dwarkarao`)
2. **Password:** Paste your token (e.g., `ghp_xxxxx...`)
3. Press Enter
4. Should see: ✅ `Branch 'main' set up to track remote branch 'main'`

---

## 🔄 SAVE TOKEN PERMANENTLY (Optional)

After first successful push, you can save the token so Git remembers it:

### macOS / Linux:
```bash
git config --global credential.helper store
```

### Windows:
```bash
git config --global credential.helper wincred
```

Then do the push once with your token. Next time, Git uses the saved token automatically!

---

## ✅ VERIFY TOKEN WORKS

Test your token:
```bash
curl -H "Authorization: token YOUR_TOKEN_HERE" https://api.github.com/user
```

Replace `YOUR_TOKEN_HERE` with your actual token.

If successful, you'll see your GitHub user info.

---

## 🔐 TOKEN SECURITY

⚠️ **Important:**
- Never share your token
- Never commit it to code
- If leaked, delete it from GitHub settings
- Create a new token if needed

To delete a token:
1. Go: https://github.com/settings/tokens
2. Find the token
3. Click **"Delete"**
4. Confirm

---

## 🆘 TROUBLESHOOTING

### "Token expired"
- Go to https://github.com/settings/tokens
- Generate a new token
- Use the new one

### "Invalid token"
- Double-check you copied the entire token
- Make sure no extra spaces
- Generate a new token and try again

### "Repository not found"
- Check username in URL is correct
- Check repository name is correct
- Make sure you ran: `git remote add origin ...`

### "Push still asks for password"
- Did you use the token as password? (not GitHub password)
- Try running: `git config --global credential.reject-all`
- Then try push again

---

## 📋 QUICK CHECKLIST

- [ ] Token created at https://github.com/settings/tokens
- [ ] Token copied and saved
- [ ] Repository created on GitHub
- [ ] Git init run in project folder
- [ ] First commit created: `git commit -m "Initial commit"`
- [ ] Remote added: `git remote add origin ...`
- [ ] Git push attempted
- [ ] Used token as password (not GitHub password)
- [ ] Push successful ✅

---

## 🎯 COMPLETE FLOW

```bash
# 1. First time setup
git init
git add .
git commit -m "Initial Fantasy IPL app"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/fantasy-ipl.git

# 2. Push (first time - will ask for credentials)
git push -u origin main

# When asked:
# Username: dwarkarao
# Password: ghp_xxxxxxxxxxxxx (your token)

# 3. Future pushes (if you saved token)
git push origin main  # No password needed!
```

---

## 📱 DIFFERENT MACHINE?

When you setup on another machine:

1. Create a **new token** (recommended for security)
2. Use that token for git push
3. Each machine can have its own token

Or reuse the same token on all machines.

---

**Still stuck? Check the complete setup guide: 00-COMPLETE-SETUP-GUIDE.md**