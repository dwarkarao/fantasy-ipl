# Fantasy IPL - Quick Command Reference

## 🚀 SETUP COMMANDS (Do once)

```bash
# 1. Create React App
npx create-react-app fantasy-ipl
cd fantasy-ipl

# 2. Install Dependencies
npm install firebase lucide-react

# 3. (Optional) Setup Tailwind CSS
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p

# 4. Initialize Git
git init

# 5. Add all files
git add .

# 6. First commit
git commit -m "Initial Fantasy IPL app"

# 7. Rename branch to main
git branch -M main

# 8. Connect to GitHub
git remote add origin https://github.com/YOUR_USERNAME/fantasy-ipl.git

# 9. Push to GitHub
git push -u origin main
```

---

## 📁 FILE REPLACEMENTS (Do once)

Replace these files with the ones provided:

| File Path | Replace With |
|-----------|--------------|
| `src/App.jsx` | `fantasy-ipl-complete-scoring.jsx` |
| `src/index.js` | `index.js` (provided) |
| `src/index.css` | `index.css` (provided) |
| `package.json` | `package.json` (provided) |
| `.gitignore` | `.gitignore` (provided) |

---

## 🧪 DEVELOPMENT COMMANDS (Use during development)

```bash
# Start development server (runs on http://localhost:3000)
npm start

# Stop server
Ctrl + C (or Cmd + C on Mac)

# Run tests
npm test

# Build for production
npm run build
```

---

## 📤 DEPLOYMENT COMMANDS (After making changes)

```bash
# See what changed
git status

# Add all changes
git add .

# Commit changes
git commit -m "Updated scoring rules" 
# (change message as needed)

# Push to GitHub (Vercel auto-deploys)
git push origin main
```

---

## 🔄 COMMON WORKFLOWS

### After Adding App Code
```bash
npm start              # Test locally
# (make sure it works)
git add src/App.jsx
git commit -m "Add Fantasy IPL app code"
git push origin main   # Vercel auto-deploys
```

### After Updating Scoring Rules
```bash
npm start              # Test locally
git add src/App.jsx
git commit -m "Update scoring rules"
git push origin main
```

### After Firebase Config Changes
```bash
npm start              # Test locally
git add src/App.jsx
git commit -m "Update Firebase config"
git push origin main
```

---

## 🆘 TROUBLESHOOTING COMMANDS

```bash
# Check Node installation
node --version
npm --version

# Check Git installation
git --version

# View current git status
git status

# View commit history
git log --oneline

# Clear npm cache (if packages won't install)
npm cache clean --force

# Reinstall all packages
rm -rf node_modules
npm install

# Check if port 3000 is in use (macOS/Linux)
lsof -i :3000

# Kill process on port 3000 (if needed)
kill -9 <PID>
```

---

## 📋 FILE CHECKLIST

After setup, your `fantasy-ipl` folder should have:

```
fantasy-ipl/
├── node_modules/
├── public/
├── src/
│   ├── App.jsx              ✅ (Your app code)
│   ├── index.js             ✅ (Entry point)
│   ├── index.css            ✅ (Styling)
│   └── App.css
├── .git/                    ✅ (Created by git init)
├── .gitignore               ✅ (Provided file)
├── package.json             ✅ (Provided file)
├── package-lock.json        ✅ (Auto-created)
├── tailwind.config.js       ✅ (Optional, if you installed Tailwind)
└── postcss.config.js        ✅ (Optional, if you installed Tailwind)
```

---

## 🎯 STEP-BY-STEP FOR NEW MACHINE

1. **Install Prerequisites**
   ```bash
   # Download and install from:
   # - Node.js: https://nodejs.org/
   # - Git: https://git-scm.com/
   ```

2. **Create App**
   ```bash
   npx create-react-app fantasy-ipl
   cd fantasy-ipl
   npm install firebase lucide-react
   ```

3. **Add Code**
   - Replace `src/App.jsx` with provided code
   - Replace `src/index.js` with provided code
   - Replace `src/index.css` with provided code

4. **Test**
   ```bash
   npm start
   # Should see app at http://localhost:3000
   ```

5. **Setup Git**
   ```bash
   git init
   git add .
   git commit -m "Initial Fantasy IPL app"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/fantasy-ipl.git
   git push -u origin main
   ```

6. **Deploy**
   - Go to https://vercel.com
   - Sign in with GitHub
   - Click "New Project"
   - Select fantasy-ipl
   - Click "Deploy"
   - Done! ✅

---

## 💡 TIPS

- Keep Terminal open in project folder
- Always use `npm install` before first run on new machine
- Commit after each feature change
- Push to GitHub regularly (auto-deploys to Vercel)
- Check `.gitignore` to exclude node_modules from Git

---

## 📱 TESTING ON DIFFERENT MACHINES

When testing on another machine:

1. Copy all provided files
2. Run `npm install` (downloads dependencies)
3. Update Firebase config in `src/App.jsx`
4. Run `npm start`
5. Everything should work immediately!

---

**Need help? Check 00-COMPLETE-SETUP-GUIDE.md for detailed instructions**